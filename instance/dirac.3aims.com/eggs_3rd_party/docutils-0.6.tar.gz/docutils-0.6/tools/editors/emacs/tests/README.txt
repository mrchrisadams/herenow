==========================================
  Tests for automatic section adjustment
==========================================

:Author: Martin Blais <blais@furius.ca>
:Date: 2005-09-03


Running the tests
=================

To run the test suite, you can either evaluate the relevant progn from within
emacs, or you can run them from the command-line like this, e.g.::

   emacs --script tests-basic.el

See the Makefile for more details.

Status
======

We are planning to write many more tests and eventually to rewrite the
interactive section adjustment because it contains a few bugs (it nonetheless
pretty much works well otherwise).  Some of those bugs have been added and are
currently failing if you run the tests.

(See the FIXME statements for where to continue.)
