"""\
A simple script for copying dependencies of a set of requirements to a directory.

WARNING: The version numbers of the dependencies are not verified.
"""
import logging
import os
from buildkit import get_requires
from shutil import copytree

log = logging.getLogger(__name__)

def copy_deps(base, deps, dst):
    log.info('%r', deps)
    if not os.path.exists(dst):
        os.mkdir(dst)
    elif not os.path.isdir(dst):
        raise Exception("%r is not a directory"%dst)
    final_deps = deps[:]
    def update_deps(dep):
        new_deps = []
        for dep in get_requires(dep, os.path.join(base, dep)):
            if not dep in final_deps:
                final_deps.append(dep)
                update_deps(dep)
    for dep in deps:
        update_deps(dep)
    for dep in final_deps:
        if dep == 'BareNecessities':
            mod = 'bn'
        elif dep == 'python-twitter':
            mod = 'twitter'
        elif dep == 'DBUtils':
            mod = 'DBUtils'
        elif dep == 'recaptcha-client':
            mod = 'recaptcha'
        else:
            mod = dep.lower()
        if os.path.exists(os.path.join(dst, mod)):
            print "Skipping '%s'"%(dep)
        elif not os.path.exists(os.path.join(base, dep, mod)):
            print "Error: No source for %r in %r"%(mod, os.path.join(base, dep, mod))
        else:
            print "Copying %r to %r"%(dep, os.path.join(dst, mod))
            copytree(os.path.join(base, dep, mod), os.path.join(dst, mod))

import getopt
from commandtool import Cmd

class UpdateSetupDependencies(Cmd):

    arg_spec = [
        ('SRC_BASE', 'The directory where BuildKit-based packages are checked out', 'No base directory containing the BuildKit-based packages specified'),
        ('DST', 'The directory where the dependencies should be added', 'No destination directory specified',),
        ('NAME', 'The name of the package'),
        ('DIR', 'The path to the directory containing the setup.py file with the dependencies', 'No directory containing the setup.py file specified',),
    ]

    help = {
        'summary': 'Update the dependencies from setup.py',
    }

    def on_run(self, service, args, opts):
        base = args[0]
        dst = args[1]
        name = args[2]
        setup_dir = args[3]
        deps = get_requires(name, setup_dir)
        copy_deps(base, deps, dst)

class UpdateArgDependencies(Cmd):

    arg_spec = [
        ('SRC_BASE', 'The directory where BuildKit-based packages are checked out', 'No base directory containing the BuildKit-based packages specified'),
        ('DST', 'The directory where the dependencies should be added', 'No destination directory specified'),
        (1, 'The dependent packages', 'No dependant packages specified', 'PACKAGE1 PACKAGE2 etc',),
    ]

    help = {
        'summary': 'Update the dependencies from a list on the command line',
    }

    def on_run(self, service, args, opts):
        base = args[0]
        dst = args[1]
        deps = args[2:]
        copy_deps(base, deps, dst)

