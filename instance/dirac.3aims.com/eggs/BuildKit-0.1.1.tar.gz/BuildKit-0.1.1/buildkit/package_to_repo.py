import os
import shutil
from subprocess import Popen

_HGIGNORE = '''\
syntax:glob
*.DS_Store
.svn
*.svn
.coverage
*.swp
*.swo
*.pyc
*.egg-info
*.db
ez_setup
*~
build/
dist/
data/
doc/build/
'''

_HG_HGRC='''\
[web]
allow_push = %(ALLOW_PUSH)s
style = custom
allow_archive = bz2 gz zip
description = %(DESCRIPTION)s
contact = %(AUTHOR_NAME)s
'''

def run(cmd, directory):
    process = Popen(
        cmd,
        cwd = directory,
    )
    stdout, stderr = process.communicate()
    retcode = process.wait()
    if retcode:
        raise Exception('Executing %r failed'%(' '.join(cmd)))

def hg_repo(PACKAGE, AUTHOR_NAME, DESCRIPTION, ALLOW_PUSH):
    #if os.path.exists('trunk'):
    #    raise Exception('Please remove the "trunk" directory in the current working directory first')
    #shutil.move(PACKAGE, 'trunk')
    #os.mkdir(PACKAGE)
    #shutil.move('trunk', os.path.join(PACKAGE, 'trunk'))
    fp = open(os.path.join(PACKAGE, '.hgignore'), 'wb')
    fp.write(_HGIGNORE)
    fp.close()
    run(['hg', 'init'], PACKAGE)
    fp = open(os.path.join(PACKAGE, '.hg', 'hgrc'), 'wb')
    fp.write(
        _HG_HGRC%dict(
            ALLOW_PUSH=ALLOW_PUSH,
            DESCRIPTION=DESCRIPTION,
            AUTHOR_NAME=AUTHOR_NAME,
        )
    )
    fp.close()
    run(['hg', 'add', '.'], PACKAGE)
    run(['hg', 'add', '.hgignore'], PACKAGE)
    run(['hg', 'ci', '-m', 'Initial import', '--user', 'buildkit@example.org'], PACKAGE)


