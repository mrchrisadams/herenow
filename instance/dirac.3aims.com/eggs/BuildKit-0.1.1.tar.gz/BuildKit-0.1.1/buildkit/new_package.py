import os, base64

EXAMPLEPACKAGE_SETUP_CFG = '''\
[egg_info]
#tag_build = dev
#tag_svn_revision = true
'''

EXAMPLEPACKAGE_LICENSE_TXT = '''\
%(PACKAGE)s - %(DESCRIPTION)s
Copyright (C) 2009 %(AUTHOR_NAME)s

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

EXAMPLEPACKAGE_SETUP_PY = '''\
try:
    from setuptools import setup, find_packages
except ImportError:
    from ez_setup import use_setuptools
    use_setuptools()
    from setuptools import setup, find_packages

import sys, os

version = '%(VERSION)s'

def read(*rnames):
    return open(os.path.join(os.path.dirname(__file__), *rnames)).read()

long_description = (
    "%(PACKAGE)s\\n"
    "++++++++++++++\\n\\n"
    ".. contents :: \\n"
    "\\n"+read('doc/index.txt')
    + '\\n'
    + read('CHANGELOG.txt')
    + '\\n'
    'License\\n'
    '=======\\n'
    + read('LICENSE.txt')
    + '\\n'
    'Download\\n'
    '========\\n'
)

setup(
    name='%(PACKAGE)s',
    version=version,
    description="%(DESCRIPTION)s",
    long_description=long_description,
    # Get classifiers from http://pypi.python.org/pypi?%%3Aaction=list_classifiers
    classifiers=[
        'Development Status :: 3 - Alpha',
        #'Environment :: Web Environment',
        'License :: OSI Approved :: GNU Affero General Public License v3',
        'Programming Language :: Python',
    ],
    keywords='',
    author='%(AUTHOR_NAME)s',
    author_email='%(AUTHOR_EMAIL)s',
    url='%(AUTHOR_URL)s/work/code/%(MODULE)s/index.html',
    license='GNU AGPLv3',
    packages=find_packages(exclude=['ez_setup', 'example', 'test']),
    include_package_data=True,
    zip_safe=False,
    install_requires=[
    ],
    extras_require={
        'test': [],
    },
    entry_points="""
    """,
)
'''

EXAMPLEPACKAGE_README_TXT = '''\
See the ``doc/index.txt`` for information.'''

EXAMPLEPACKAGE_CHANGELOG_TXT = '''\
Changes
=======

%(VERSION)s
-----

2009-12-23
~~~~~~~~~~

* First version
'''

EXAMPLEPACKAGE_EZ_SETUP_PY = '''\
#!python
"""Bootstrap setuptools installation

If you want to use setuptools in your package's setup.py, just include this
file in the same directory with it, and add this to the top of your setup.py::

    from ez_setup import use_setuptools
    use_setuptools()

If you want to require a specific version of setuptools, set a download
mirror, or use an alternate download directory, you can do so by supplying
the appropriate options to ``use_setuptools()``.

This file can also be run as a script to install or upgrade setuptools.
"""
import sys
DEFAULT_VERSION = "0.6c11"
DEFAULT_URL     = "http://pypi.python.org/packages/%%s/s/setuptools/" %% sys.version[:3]

md5_data = {
    'setuptools-0.6b1-py2.3.egg': '8822caf901250d848b996b7f25c6e6ca',
    'setuptools-0.6b1-py2.4.egg': 'b79a8a403e4502fbb85ee3f1941735cb',
    'setuptools-0.6b2-py2.3.egg': '5657759d8a6d8fc44070a9d07272d99b',
    'setuptools-0.6b2-py2.4.egg': '4996a8d169d2be661fa32a6e52e4f82a',
    'setuptools-0.6b3-py2.3.egg': 'bb31c0fc7399a63579975cad9f5a0618',
    'setuptools-0.6b3-py2.4.egg': '38a8c6b3d6ecd22247f179f7da669fac',
    'setuptools-0.6b4-py2.3.egg': '62045a24ed4e1ebc77fe039aa4e6f7e5',
    'setuptools-0.6b4-py2.4.egg': '4cb2a185d228dacffb2d17f103b3b1c4',
    'setuptools-0.6c1-py2.3.egg': 'b3f2b5539d65cb7f74ad79127f1a908c',
    'setuptools-0.6c1-py2.4.egg': 'b45adeda0667d2d2ffe14009364f2a4b',
    'setuptools-0.6c10-py2.3.egg': 'ce1e2ab5d3a0256456d9fc13800a7090',
    'setuptools-0.6c10-py2.4.egg': '57d6d9d6e9b80772c59a53a8433a5dd4',
    'setuptools-0.6c10-py2.5.egg': 'de46ac8b1c97c895572e5e8596aeb8c7',
    'setuptools-0.6c10-py2.6.egg': '58ea40aef06da02ce641495523a0b7f5',
    'setuptools-0.6c11-py2.3.egg': '2baeac6e13d414a9d28e7ba5b5a596de',
    'setuptools-0.6c11-py2.4.egg': 'bd639f9b0eac4c42497034dec2ec0c2b',
    'setuptools-0.6c11-py2.5.egg': '64c94f3bf7a72a13ec83e0b24f2749b2',
    'setuptools-0.6c11-py2.6.egg': 'bfa92100bd772d5a213eedd356d64086',
    'setuptools-0.6c2-py2.3.egg': 'f0064bf6aa2b7d0f3ba0b43f20817c27',
    'setuptools-0.6c2-py2.4.egg': '616192eec35f47e8ea16cd6a122b7277',
    'setuptools-0.6c3-py2.3.egg': 'f181fa125dfe85a259c9cd6f1d7b78fa',
    'setuptools-0.6c3-py2.4.egg': 'e0ed74682c998bfb73bf803a50e7b71e',
    'setuptools-0.6c3-py2.5.egg': 'abef16fdd61955514841c7c6bd98965e',
    'setuptools-0.6c4-py2.3.egg': 'b0b9131acab32022bfac7f44c5d7971f',
    'setuptools-0.6c4-py2.4.egg': '2a1f9656d4fbf3c97bf946c0a124e6e2',
    'setuptools-0.6c4-py2.5.egg': '8f5a052e32cdb9c72bcf4b5526f28afc',
    'setuptools-0.6c5-py2.3.egg': 'ee9fd80965da04f2f3e6b3576e9d8167',
    'setuptools-0.6c5-py2.4.egg': 'afe2adf1c01701ee841761f5bcd8aa64',
    'setuptools-0.6c5-py2.5.egg': 'a8d3f61494ccaa8714dfed37bccd3d5d',
    'setuptools-0.6c6-py2.3.egg': '35686b78116a668847237b69d549ec20',
    'setuptools-0.6c6-py2.4.egg': '3c56af57be3225019260a644430065ab',
    'setuptools-0.6c6-py2.5.egg': 'b2f8a7520709a5b34f80946de5f02f53',
    'setuptools-0.6c7-py2.3.egg': '209fdf9adc3a615e5115b725658e13e2',
    'setuptools-0.6c7-py2.4.egg': '5a8f954807d46a0fb67cf1f26c55a82e',
    'setuptools-0.6c7-py2.5.egg': '45d2ad28f9750e7434111fde831e8372',
    'setuptools-0.6c8-py2.3.egg': '50759d29b349db8cfd807ba8303f1902',
    'setuptools-0.6c8-py2.4.egg': 'cba38d74f7d483c06e9daa6070cce6de',
    'setuptools-0.6c8-py2.5.egg': '1721747ee329dc150590a58b3e1ac95b',
    'setuptools-0.6c9-py2.3.egg': 'a83c4020414807b496e4cfbe08507c03',
    'setuptools-0.6c9-py2.4.egg': '260a2be2e5388d66bdaee06abec6342a',
    'setuptools-0.6c9-py2.5.egg': 'fe67c3e5a17b12c0e7c541b7ea43a8e6',
    'setuptools-0.6c9-py2.6.egg': 'ca37b1ff16fa2ede6e19383e7b59245a',
}

import sys, os
try: from hashlib import md5
except ImportError: from md5 import md5

def _validate_md5(egg_name, data):
    if egg_name in md5_data:
        digest = md5(data).hexdigest()
        if digest != md5_data[egg_name]:
            print >>sys.stderr, (
                "md5 validation of %%s failed!  (Possible download problem?)"
                %% egg_name
            )
            sys.exit(2)
    return data

def use_setuptools(
    version=DEFAULT_VERSION, download_base=DEFAULT_URL, to_dir=os.curdir,
    download_delay=15
):
    """Automatically find/download setuptools and make it available on sys.path

    `version` should be a valid setuptools version number that is available
    as an egg for download under the `download_base` URL (which should end with
    a '/').  `to_dir` is the directory where setuptools will be downloaded, if
    it is not already available.  If `download_delay` is specified, it should
    be the number of seconds that will be paused before initiating a download,
    should one be required.  If an older version of setuptools is installed,
    this routine will print a message to ``sys.stderr`` and raise SystemExit in
    an attempt to abort the calling script.
    """
    was_imported = 'pkg_resources' in sys.modules or 'setuptools' in sys.modules
    def do_download():
        egg = download_setuptools(version, download_base, to_dir, download_delay)
        sys.path.insert(0, egg)
        import setuptools; setuptools.bootstrap_install_from = egg
    try:
        import pkg_resources
    except ImportError:
        return do_download()       
    try:
        pkg_resources.require("setuptools>="+version); return
    except pkg_resources.VersionConflict, e:
        if was_imported:
            print >>sys.stderr, (
            "The required version of setuptools (>=%%s) is not available, and\\n"
            "can't be installed while this script is running. Please install\\n"
            " a more recent version first, using 'easy_install -U setuptools'."
            "\\n\\n(Currently using %%r)"
            ) %% (version, e.args[0])
            sys.exit(2)
        else:
            del pkg_resources, sys.modules['pkg_resources']    # reload ok
            return do_download()
    except pkg_resources.DistributionNotFound:
        return do_download()

def download_setuptools(
    version=DEFAULT_VERSION, download_base=DEFAULT_URL, to_dir=os.curdir,
    delay = 15
):
    """Download setuptools from a specified location and return its filename

    `version` should be a valid setuptools version number that is available
    as an egg for download under the `download_base` URL (which should end
    with a '/'). `to_dir` is the directory where the egg will be downloaded.
    `delay` is the number of seconds to pause before an actual download attempt.
    """
    import urllib2, shutil
    egg_name = "setuptools-%%s-py%%s.egg" %% (version,sys.version[:3])
    url = download_base + egg_name
    saveto = os.path.join(to_dir, egg_name)
    src = dst = None
    if not os.path.exists(saveto):  # Avoid repeated downloads
        try:
            from distutils import log
            if delay:
                log.warn("""
---------------------------------------------------------------------------
This script requires setuptools version %%s to run (even to display
help).  I will attempt to download it for you (from
%%s), but
you may need to enable firewall access for this script first.
I will start the download in %%d seconds.

(Note: if this machine does not have network access, please obtain the file

   %%s

and place it in this directory before rerunning this script.)
---------------------------------------------------------------------------""",
                    version, download_base, delay, url
                ); from time import sleep; sleep(delay)
            log.warn("Downloading %%s", url)
            src = urllib2.urlopen(url)
            # Read/write all in one block, so we don't create a corrupt file
            # if the download is interrupted.
            data = _validate_md5(egg_name, src.read())
            dst = open(saveto,"wb"); dst.write(data)
        finally:
            if src: src.close()
            if dst: dst.close()
    return os.path.realpath(saveto)




































def main(argv, version=DEFAULT_VERSION):
    """Install or upgrade setuptools and EasyInstall"""
    try:
        import setuptools
    except ImportError:
        egg = None
        try:
            egg = download_setuptools(version, delay=0)
            sys.path.insert(0,egg)
            from setuptools.command.easy_install import main
            return main(list(argv)+[egg])   # we're done here
        finally:
            if egg and os.path.exists(egg):
                os.unlink(egg)
    else:
        if setuptools.__version__ == '0.0.1':
            print >>sys.stderr, (
            "You have an obsolete version of setuptools installed.  Please\\n"
            "remove it from your system entirely before rerunning this script."
            )
            sys.exit(2)

    req = "setuptools>="+version
    import pkg_resources
    try:
        pkg_resources.require(req)
    except pkg_resources.VersionConflict:
        try:
            from setuptools.command.easy_install import main
        except ImportError:
            from easy_install import main
        main(list(argv)+[download_setuptools(delay=0)])
        sys.exit(0) # try to force an exit
    else:
        if argv:
            from setuptools.command.easy_install import main
            main(argv)
        else:
            print "Setuptools version",version,"or greater has been installed."
            print '(Run "ez_setup.py -U setuptools" to reinstall or upgrade.)'

def update_md5(filenames):
    """Update our built-in md5 registry"""

    import re

    for name in filenames:
        base = os.path.basename(name)
        f = open(name,'rb')
        md5_data[base] = md5(f.read()).hexdigest()
        f.close()

    data = ["    %%r: %%r,\\n" %% it for it in md5_data.items()]
    data.sort()
    repl = "".join(data)

    import inspect
    srcfile = inspect.getsourcefile(sys.modules[__name__])
    f = open(srcfile, 'rb'); src = f.read(); f.close()

    match = re.search("\\nmd5_data = {\\n([^}]+)}", src)
    if not match:
        print >>sys.stderr, "Internal error!"
        sys.exit(2)

    src = src[:match.start(1)] + repl + src[match.end(1):]
    f = open(srcfile,'w')
    f.write(src)
    f.close()


if __name__=='__main__':
    if len(sys.argv)>2 and sys.argv[1]=='--md5update':
        update_md5(sys.argv[2:])
    else:
        main(sys.argv[1:])






'''

EXAMPLEPACKAGE_MANIFEST_IN = '''\

include doc/index.txt
include doc/Makefile
include doc/source/*.rst
include doc/source/conf.py
include test/*
include example/*
include ez_setup.py
include CHANGELOG.txt
include LICENSE.txt'''

EXAMPLEPACKAGE_EXAMPLE_README_TXT = '''\
Examples go in this directory'''

EXAMPLEPACKAGE_TEST_DOC_PY = '''\
"""
Doctests for %(PACKAGE)s
"""
import doctest
import logging
logging.basicConfig(level=logging.DEBUG)

import sys; sys.path.append('../')

doctest.testfile('../doc/source/manual.rst', optionflags=doctest.ELLIPSIS)
doctest.testfile('../doc/source/api.rst', optionflags=doctest.ELLIPSIS)
'''

EXAMPLEPACKAGE_TEST_README_TXT = '''\
Tests go in this directory'''

EXAMPLEPACKAGE_DOC_MAKEFILE = '''\
# Makefile for Sphinx documentation
#

# You can set these variables from the command line.
SPHINXOPTS    =
SPHINXBUILD   = ~/env/bin/sphinx-build
PAPER         =
BUILDDIR      = build

# Internal variables.
PAPEROPT_a4     = -D latex_paper_size=a4
PAPEROPT_letter = -D latex_paper_size=letter
ALLSPHINXOPTS   = -d $(BUILDDIR)/doctrees $(PAPEROPT_$(PAPER)) $(SPHINXOPTS) source

.PHONY: help clean html dirhtml pickle json htmlhelp qthelp latex changes linkcheck doctest

help:
	@echo "Please use `make <target>' where <target> is one of"
	@echo "  html      to make standalone HTML files"
	@echo "  dirhtml   to make HTML files named index.html in directories"
	@echo "  pickle    to make pickle files"
	@echo "  json      to make JSON files"
	@echo "  htmlhelp  to make HTML files and a HTML help project"
	@echo "  qthelp    to make HTML files and a qthelp project"
	@echo "  latex     to make LaTeX files, you can set PAPER=a4 or PAPER=letter"
	@echo "  changes   to make an overview of all changed/added/deprecated items"
	@echo "  linkcheck to check all external links for integrity"
	@echo "  doctest   to run all doctests embedded in the documentation (if enabled)"

clean:
	-rm -rf $(BUILDDIR)/*

html:
	$(SPHINXBUILD) -b html $(ALLSPHINXOPTS) $(BUILDDIR)/html
	@echo
	@echo "Build finished. The HTML pages are in $(BUILDDIR)/html."

dirhtml:
	$(SPHINXBUILD) -b dirhtml $(ALLSPHINXOPTS) $(BUILDDIR)/dirhtml
	@echo
	@echo "Build finished. The HTML pages are in $(BUILDDIR)/dirhtml."

pickle:
	$(SPHINXBUILD) -b pickle $(ALLSPHINXOPTS) $(BUILDDIR)/pickle
	@echo
	@echo "Build finished; now you can process the pickle files."

json:
	$(SPHINXBUILD) -b json $(ALLSPHINXOPTS) $(BUILDDIR)/json
	@echo
	@echo "Build finished; now you can process the JSON files."

htmlhelp:
	$(SPHINXBUILD) -b htmlhelp $(ALLSPHINXOPTS) $(BUILDDIR)/htmlhelp
	@echo
	@echo "Build finished; now you can run HTML Help Workshop with the" \\
	      ".hhp project file in $(BUILDDIR)/htmlhelp."

qthelp:
	$(SPHINXBUILD) -b qthelp $(ALLSPHINXOPTS) $(BUILDDIR)/qthelp
	@echo
	@echo "Build finished; now you can run "qcollectiongenerator" with the" \\
	      ".qhcp project file in $(BUILDDIR)/qthelp, like this:"
	@echo "# qcollectiongenerator $(BUILDDIR)/qthelp/PermissionKit.qhcp"
	@echo "To view the help file:"
	@echo "# assistant -collectionFile $(BUILDDIR)/qthelp/PermissionKit.qhc"

latex:
	$(SPHINXBUILD) -b latex $(ALLSPHINXOPTS) $(BUILDDIR)/latex
	@echo
	@echo "Build finished; the LaTeX files are in $(BUILDDIR)/latex."
	@echo "Run `make all-pdf' or `make all-ps' in that directory to" \\
	      "run these through (pdf)latex."

changes:
	$(SPHINXBUILD) -b changes $(ALLSPHINXOPTS) $(BUILDDIR)/changes
	@echo
	@echo "The overview file is in $(BUILDDIR)/changes."

linkcheck:
	$(SPHINXBUILD) -b linkcheck $(ALLSPHINXOPTS) $(BUILDDIR)/linkcheck
	@echo
	@echo "Link check complete; look for any errors in the above output " \\
	      "or in $(BUILDDIR)/linkcheck/output.txt."

doctest:
	$(SPHINXBUILD) -b doctest $(ALLSPHINXOPTS) $(BUILDDIR)/doctest
	@echo "Testing of doctests in the sources finished, look at the " \\
	      "results in $(BUILDDIR)/doctest/output.txt."
'''

EXAMPLEPACKAGE_DOC_INDEX_TXT = '''\
Summary
=======

%(DESCRIPTION)s

Get Started
===========

* Download and install from source

Author
======

`%(AUTHOR_NAME)s <%(AUTHOR_URL)s>`_

'''

EXAMPLEPACKAGE_DOC_SOURCE_INDEX_RST = '''\
%(VERSION)s
+++++

.. include :: ../index.txt

Documentation
=============

.. toctree::
   :maxdepth: 2

   manual
   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
'''

EXAMPLEPACKAGE_DOC_SOURCE_API_RST = '''\
API Documentation
+++++++++++++++++
   
.. automodule:: %(MODULE)s 
   :members:
   :undoc-members:
'''

EXAMPLEPACKAGE_DOC_SOURCE_CONF_PY = '''\
# -*- coding: utf-8 -*-
#
# %(PACKAGE)s documentation build configuration file, based on 
# sphinx-quickstart created in 2009.
#  
# This file is execfile()d with the current directory set to its containing dir.
#
# Note that not all possible configuration values are present in this
# autogenerated file.
#
# All configuration values have a %(THEME)s; values that are commented out
# serve to show the %(THEME)s.

import sys, os

# If extensions (or modules to document with autodoc) are in another directory,
# add these directories to sys.path here. If the directory is relative to the
# documentation root, use os.path.abspath to make it absolute, like shown here.
#sys.path.append(os.path.abspath('.'))

# -- General configuration -----------------------------------------------------

# Add any Sphinx extension module names here, as strings. They can be extensions
# coming with Sphinx (named 'sphinx.ext.*') or your custom ones.
extensions = ['sphinx.ext.autodoc', 'sphinx.ext.doctest']

# Add any paths that contain templates here, relative to this directory.
templates_path = ['_templates']

# The suffix of source filenames.
source_suffix = '.rst'

# The encoding of source files.
#source_encoding = 'utf-8'

# The master toctree document.
master_doc = 'index'

# General information about the project.
project = u'%(PACKAGE)s'
copyright = u'2009, %(AUTHOR_NAME)s'

# The version info for the project you're documenting, acts as replacement for
# |version| and |release|, also used in various other places throughout the
# built documents.
#
# The short X.Y version.
version = '%(VERSION)s'
# The full version, including alpha/beta/rc tags.
release = '%(VERSION)s'

# The language for content autogenerated by Sphinx. Refer to documentation
# for a list of supported languages.
#language = None

# There are two options for replacing |today|: either, you set today to some
# non-false value, then it is used:
#today = ''
# Else, today_fmt is used as the format for a strftime call.
#today_fmt = '%%B %%d, %%Y'

# List of documents that shouldn't be included in the build.
#unused_docs = []

# List of directories, relative to source directory, that shouldn't be searched
# for source files.
exclude_trees = []

# The reST %(THEME)s role (used for this markup: `text`) to use for all documents.
#%(THEME)s_role = None

# If true, '()' will be appended to :func: etc. cross-reference text.
#add_function_parentheses = True

# If true, the current module name will be prepended to all description
# unit titles (such as .. function::).
#add_module_names = True

# If true, sectionauthor and moduleauthor directives will be shown in the
# output. They are ignored by %(THEME)s.
#show_authors = False

# The name of the Pygments (syntax highlighting) style to use.
pygments_style = 'sphinx'

# A list of ignored prefixes for module index sorting.
#modindex_common_prefix = []


# -- Options for HTML output ---------------------------------------------------

# The theme to use for HTML and HTML Help pages.  Major themes that come with
# Sphinx are currently '%(THEME)s' and 'sphinxdoc'.
html_theme = '%(THEME)s'

# Theme options are theme-specific and customize the look and feel of a theme
# further.  For a list of options available for each theme, see the
# documentation.
#html_theme_options = {}

# Add any paths that contain custom themes here, relative to this directory.
#html_theme_path = []

# The name for this set of Sphinx documents.  If None, it %(THEME)ss to
# "<project> v<release> documentation".
#html_title = None

# A shorter title for the navigation bar.  Default is the same as html_title.
#html_short_title = None

# The name of an image file (relative to this directory) to place at the top
# of the sidebar.
#html_logo = None

# The name of an image file (within the static path) to use as favicon of the
# docs.  This file should be a Windows icon file (.ico) being 16x16 or 32x32
# pixels large.
#html_favicon = None

# Add any paths that contain custom static files (such as style sheets) here,
# relative to this directory. They are copied after the builtin static files,
# so a file named "%(THEME)s.css" will overwrite the builtin "%(THEME)s.css".
html_static_path = ['_static']

# If not '', a 'Last updated on:' timestamp is inserted at every page bottom,
# using the given strftime format.
#html_last_updated_fmt = '%%b %%d, %%Y'

# If true, SmartyPants will be used to convert quotes and dashes to
# typographically correct entities.
#html_use_smartypants = True

# Custom sidebar templates, maps document names to template names.
#html_sidebars = {}

# Additional templates that should be rendered to pages, maps page names to
# template names.
#html_additional_pages = {}

# If false, no module index is generated.
#html_use_modindex = True

# If false, no index is generated.
#html_use_index = True

# If true, the index is split into individual pages for each letter.
#html_split_index = False

# If true, links to the reST sources are added to the pages.
#html_show_sourcelink = True

# If true, an OpenSearch description file will be output, and all pages will
# contain a <link> tag referring to it.  The value of this option must be the
# base URL from which the finished HTML is served.
#html_use_opensearch = ''
# If nonempty, this is the file name suffix for HTML files (e.g. ".xhtml").
#html_file_suffix = ''

# Output file base name for HTML help builder.
htmlhelp_basename = '%(PACKAGE)sdoc'


# -- Options for LaTeX output --------------------------------------------------

# The paper size ('letter' or 'a4').
#latex_paper_size = 'letter'

# The font size ('10pt', '11pt' or '12pt').
#latex_font_size = '10pt'

# Grouping the document tree into LaTeX files. List of tuples
# (source start file, target name, title, author, documentclass [howto/manual]).
latex_documents = [
  ('index', '%(PACKAGE)s.tex', u'%(PACKAGE)s Documentation',
   u'%(AUTHOR_NAME)s', 'manual'),
]

# The name of an image file (relative to this directory) to place at the top of
# the title page.
#latex_logo = None

# For "manual" documents, if this is true, then toplevel headings are parts,
# not chapters.
#latex_use_parts = False

# Additional stuff for the LaTeX preamble.
#latex_preamble = ''

# Documents to append as an appendix to all manuals.
#latex_appendices = []

# If false, no module index is generated.
#latex_use_modindex = True
'''

EXAMPLEPACKAGE_DOC_SOURCE_MANUAL_RST = '''\
Manual
++++++

Not written yet.
'''

EXAMPLEPACKAGE_EXAMPLEPACKAGE___INIT___PY = '''\
'''
def render(PACKAGE, AUTHOR_NAME, DESCRIPTION, AUTHOR_URL, VERSION, MODULE, AUTHOR_EMAIL, THEME):
    if os.path.exists("%(PACKAGE)s"%dict(PACKAGE=PACKAGE)):
        raise Exception("Directory already exists: "+"%(PACKAGE)s"%dict(PACKAGE=PACKAGE))
    os.mkdir("%(PACKAGE)s"%dict(PACKAGE=PACKAGE))
    if os.path.exists("%(PACKAGE)s/example"%dict(PACKAGE=PACKAGE)):
        raise Exception("Directory already exists: "+"%(PACKAGE)s/example"%dict(PACKAGE=PACKAGE))
    os.mkdir("%(PACKAGE)s/example"%dict(PACKAGE=PACKAGE))
    if os.path.exists("%(PACKAGE)s/test"%dict(PACKAGE=PACKAGE)):
        raise Exception("Directory already exists: "+"%(PACKAGE)s/test"%dict(PACKAGE=PACKAGE))
    os.mkdir("%(PACKAGE)s/test"%dict(PACKAGE=PACKAGE))
    if os.path.exists("%(PACKAGE)s/doc"%dict(PACKAGE=PACKAGE)):
        raise Exception("Directory already exists: "+"%(PACKAGE)s/doc"%dict(PACKAGE=PACKAGE))
    os.mkdir("%(PACKAGE)s/doc"%dict(PACKAGE=PACKAGE))
    if os.path.exists("%(PACKAGE)s/%(MODULE)s"%dict(PACKAGE=PACKAGE, MODULE=MODULE)):
        raise Exception("Directory already exists: "+"%(PACKAGE)s/%(MODULE)s"%dict(PACKAGE=PACKAGE, MODULE=MODULE))
    os.mkdir("%(PACKAGE)s/%(MODULE)s"%dict(PACKAGE=PACKAGE, MODULE=MODULE))
    if os.path.exists("%(PACKAGE)s/doc/source"%dict(PACKAGE=PACKAGE)):
        raise Exception("Directory already exists: "+"%(PACKAGE)s/doc/source"%dict(PACKAGE=PACKAGE))
    os.mkdir("%(PACKAGE)s/doc/source"%dict(PACKAGE=PACKAGE))
    if os.path.exists("%(PACKAGE)s/doc/build"%dict(PACKAGE=PACKAGE)):
        raise Exception("Directory already exists: "+"%(PACKAGE)s/doc/build"%dict(PACKAGE=PACKAGE))
    os.mkdir("%(PACKAGE)s/doc/build"%dict(PACKAGE=PACKAGE))
    if os.path.exists('%(PACKAGE)s/setup.cfg'%dict(PACKAGE=PACKAGE)):
        raise Exception('File already exists: '+'%(PACKAGE)s/setup.cfg'%dict(PACKAGE=PACKAGE))
    fp = open('%(PACKAGE)s/setup.cfg'%dict(PACKAGE=PACKAGE), 'wb')
    fp.write(EXAMPLEPACKAGE_SETUP_CFG%dict())
    fp.close()
    if os.path.exists('%(PACKAGE)s/LICENSE.txt'%dict(PACKAGE=PACKAGE)):
        raise Exception('File already exists: '+'%(PACKAGE)s/LICENSE.txt'%dict(PACKAGE=PACKAGE))
    fp = open('%(PACKAGE)s/LICENSE.txt'%dict(PACKAGE=PACKAGE), 'wb')
    fp.write(EXAMPLEPACKAGE_LICENSE_TXT%dict(AUTHOR_NAME=AUTHOR_NAME, PACKAGE=PACKAGE, DESCRIPTION=DESCRIPTION))
    fp.close()
    if os.path.exists('%(PACKAGE)s/setup.py'%dict(PACKAGE=PACKAGE)):
        raise Exception('File already exists: '+'%(PACKAGE)s/setup.py'%dict(PACKAGE=PACKAGE))
    fp = open('%(PACKAGE)s/setup.py'%dict(PACKAGE=PACKAGE), 'wb')
    fp.write(EXAMPLEPACKAGE_SETUP_PY%dict(AUTHOR_URL=AUTHOR_URL, AUTHOR_NAME=AUTHOR_NAME, PACKAGE=PACKAGE, DESCRIPTION=DESCRIPTION, VERSION=VERSION, MODULE=MODULE, AUTHOR_EMAIL=AUTHOR_EMAIL))
    fp.close()
    if os.path.exists('%(PACKAGE)s/README.txt'%dict(PACKAGE=PACKAGE)):
        raise Exception('File already exists: '+'%(PACKAGE)s/README.txt'%dict(PACKAGE=PACKAGE))
    fp = open('%(PACKAGE)s/README.txt'%dict(PACKAGE=PACKAGE), 'wb')
    fp.write(EXAMPLEPACKAGE_README_TXT%dict())
    fp.close()
    if os.path.exists('%(PACKAGE)s/CHANGELOG.txt'%dict(PACKAGE=PACKAGE)):
        raise Exception('File already exists: '+'%(PACKAGE)s/CHANGELOG.txt'%dict(PACKAGE=PACKAGE))
    fp = open('%(PACKAGE)s/CHANGELOG.txt'%dict(PACKAGE=PACKAGE), 'wb')
    fp.write(EXAMPLEPACKAGE_CHANGELOG_TXT%dict(VERSION=VERSION))
    fp.close()
    if os.path.exists('%(PACKAGE)s/ez_setup.py'%dict(PACKAGE=PACKAGE)):
        raise Exception('File already exists: '+'%(PACKAGE)s/ez_setup.py'%dict(PACKAGE=PACKAGE))
    fp = open('%(PACKAGE)s/ez_setup.py'%dict(PACKAGE=PACKAGE), 'wb')
    fp.write(EXAMPLEPACKAGE_EZ_SETUP_PY%dict())
    fp.close()
    if os.path.exists('%(PACKAGE)s/MANIFEST.in'%dict(PACKAGE=PACKAGE)):
        raise Exception('File already exists: '+'%(PACKAGE)s/MANIFEST.in'%dict(PACKAGE=PACKAGE))
    fp = open('%(PACKAGE)s/MANIFEST.in'%dict(PACKAGE=PACKAGE), 'wb')
    fp.write(EXAMPLEPACKAGE_MANIFEST_IN%dict())
    fp.close()
    if os.path.exists('%(PACKAGE)s/example/README.txt'%dict(PACKAGE=PACKAGE)):
        raise Exception('File already exists: '+'%(PACKAGE)s/example/README.txt'%dict(PACKAGE=PACKAGE))
    fp = open('%(PACKAGE)s/example/README.txt'%dict(PACKAGE=PACKAGE), 'wb')
    fp.write(EXAMPLEPACKAGE_EXAMPLE_README_TXT%dict())
    fp.close()
    if os.path.exists('%(PACKAGE)s/test/doc.py'%dict(PACKAGE=PACKAGE)):
        raise Exception('File already exists: '+'%(PACKAGE)s/test/doc.py'%dict(PACKAGE=PACKAGE))
    fp = open('%(PACKAGE)s/test/doc.py'%dict(PACKAGE=PACKAGE), 'wb')
    fp.write(EXAMPLEPACKAGE_TEST_DOC_PY%dict(PACKAGE=PACKAGE))
    fp.close()
    if os.path.exists('%(PACKAGE)s/test/README.txt'%dict(PACKAGE=PACKAGE)):
        raise Exception('File already exists: '+'%(PACKAGE)s/test/README.txt'%dict(PACKAGE=PACKAGE))
    fp = open('%(PACKAGE)s/test/README.txt'%dict(PACKAGE=PACKAGE), 'wb')
    fp.write(EXAMPLEPACKAGE_TEST_README_TXT%dict())
    fp.close()
    if os.path.exists('%(PACKAGE)s/doc/Makefile'%dict(PACKAGE=PACKAGE)):
        raise Exception('File already exists: '+'%(PACKAGE)s/doc/Makefile'%dict(PACKAGE=PACKAGE))
    fp = open('%(PACKAGE)s/doc/Makefile'%dict(PACKAGE=PACKAGE), 'wb')
    fp.write(EXAMPLEPACKAGE_DOC_MAKEFILE%dict())
    fp.close()
    if os.path.exists('%(PACKAGE)s/doc/index.txt'%dict(PACKAGE=PACKAGE)):
        raise Exception('File already exists: '+'%(PACKAGE)s/doc/index.txt'%dict(PACKAGE=PACKAGE))
    fp = open('%(PACKAGE)s/doc/index.txt'%dict(PACKAGE=PACKAGE), 'wb')
    fp.write(EXAMPLEPACKAGE_DOC_INDEX_TXT%dict(AUTHOR_URL=AUTHOR_URL, AUTHOR_NAME=AUTHOR_NAME, DESCRIPTION=DESCRIPTION))
    fp.close()
    if os.path.exists('%(PACKAGE)s/doc/source/index.rst'%dict(PACKAGE=PACKAGE)):
        raise Exception('File already exists: '+'%(PACKAGE)s/doc/source/index.rst'%dict(PACKAGE=PACKAGE))
    fp = open('%(PACKAGE)s/doc/source/index.rst'%dict(PACKAGE=PACKAGE), 'wb')
    fp.write(EXAMPLEPACKAGE_DOC_SOURCE_INDEX_RST%dict(VERSION=VERSION))
    fp.close()
    if os.path.exists('%(PACKAGE)s/doc/source/api.rst'%dict(PACKAGE=PACKAGE)):
        raise Exception('File already exists: '+'%(PACKAGE)s/doc/source/api.rst'%dict(PACKAGE=PACKAGE))
    fp = open('%(PACKAGE)s/doc/source/api.rst'%dict(PACKAGE=PACKAGE), 'wb')
    fp.write(EXAMPLEPACKAGE_DOC_SOURCE_API_RST%dict(MODULE=MODULE))
    fp.close()
    if os.path.exists('%(PACKAGE)s/doc/source/conf.py'%dict(PACKAGE=PACKAGE)):
        raise Exception('File already exists: '+'%(PACKAGE)s/doc/source/conf.py'%dict(PACKAGE=PACKAGE))
    fp = open('%(PACKAGE)s/doc/source/conf.py'%dict(PACKAGE=PACKAGE), 'wb')
    fp.write(EXAMPLEPACKAGE_DOC_SOURCE_CONF_PY%dict(AUTHOR_NAME=AUTHOR_NAME, THEME=THEME, PACKAGE=PACKAGE, VERSION=VERSION))
    fp.close()
    if os.path.exists('%(PACKAGE)s/doc/source/manual.rst'%dict(PACKAGE=PACKAGE)):
        raise Exception('File already exists: '+'%(PACKAGE)s/doc/source/manual.rst'%dict(PACKAGE=PACKAGE))
    fp = open('%(PACKAGE)s/doc/source/manual.rst'%dict(PACKAGE=PACKAGE), 'wb')
    fp.write(EXAMPLEPACKAGE_DOC_SOURCE_MANUAL_RST%dict())
    fp.close()
    if os.path.exists('%(PACKAGE)s/%(MODULE)s/__init__.py'%dict(PACKAGE=PACKAGE, MODULE=MODULE)):
        raise Exception('File already exists: '+'%(PACKAGE)s/%(MODULE)s/__init__.py'%dict(PACKAGE=PACKAGE, MODULE=MODULE))
    fp = open('%(PACKAGE)s/%(MODULE)s/__init__.py'%dict(PACKAGE=PACKAGE, MODULE=MODULE), 'wb')
    fp.write(EXAMPLEPACKAGE_EXAMPLEPACKAGE___INIT___PY%dict())
    fp.close()


