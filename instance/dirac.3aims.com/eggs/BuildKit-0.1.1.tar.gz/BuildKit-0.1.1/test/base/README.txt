This is the base directory for all the different packages BuildKit will maintain. It is used by the tests.
