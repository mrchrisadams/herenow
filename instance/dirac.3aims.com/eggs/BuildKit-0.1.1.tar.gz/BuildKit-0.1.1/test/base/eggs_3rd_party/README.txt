Third party eggs needed by BuildKit or which are dependencies of other packages go here.
