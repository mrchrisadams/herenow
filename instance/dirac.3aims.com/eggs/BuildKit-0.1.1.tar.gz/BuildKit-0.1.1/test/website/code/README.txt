This is where the documentation gets built. It is used by the tests.
