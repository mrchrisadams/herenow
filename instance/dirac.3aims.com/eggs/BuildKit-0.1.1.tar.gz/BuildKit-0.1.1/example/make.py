from buildkit.make import copy_deps

copy_deps('/home/james/Desktop/Cur/', ['RecordConvert'], '/home/james/Desktop/CarbageDeps')

