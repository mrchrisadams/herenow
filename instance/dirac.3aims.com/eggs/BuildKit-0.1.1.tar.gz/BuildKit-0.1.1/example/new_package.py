from buildkit.new_package import render

render(
    PACKAGE='ExamplePackage',
    AUTHOR_NAME='James Gardner',
    DESCRIPTION='An example package',
    AUTHOR_URL='http://jimmyg.org',
    VERSION='0.1.0',
    MODULE='examplepackage',
    AUTHOR_EMAIL='james@<package hompage URL>',
    THEME='default',
)
