from buildkit.package_to_repo import hg_repo
    
hg_repo(
    PACKAGE='ExamplePackage',
    AUTHOR_NAME='James Gardner',
    DESCRIPTION='An example package',
    ALLOW_PUSH='thejimmyg',
)

