import sys
import os
import buildkit

# Variables
base = os.getcwd()
docs_path = os.path.join(base, 'website', 'work', 'code')
template_path = os.path.join(base, 'website', 'Templates', 'main.dwt')
exclude = ['eggs', 'eggs_3rd_party', 'website', 'GradwellLibs', 'AuthKit']
# Get package list
packages = []
if len(sys.argv)>1:
    packages.append(sys.argv[1])
    if packages[0].endswith('/'):
        packages[0] = packages[0][:-1]
else:
    for directory in os.listdir(base):
        if os.path.isdir(directory) and directory not in exclude:
            packages.append(directory)
packages.sort()
print "Processing these packages: ", (', '.join(packages))
# Get all the distributions up to date for the tests
for package in packages:
    print "Building %r"%package
    buildkit.remove_dist(os.path.join(base, package))
    buildkit.build_dist(
        path=os.path.join(base, package),
        third_party_eggs_path=os.path.join(base, 'eggs_3rd_party'),
        python='python2.6',
        setuptools_version='setuptools-0.6c11-py2.6.egg',
    )
    buildkit.prepare_sources(
        os.path.join(base, package, 'dist'), 
        os.path.join(base, 'eggs'),
    )
# Build and test packages
for package in packages:
    print "Testing %r"%package
    buildkit.test_dist(
        requirement=package, 
        path=os.path.join(base, package),
        eggs_path=os.path.join(base, 'eggs'),
        third_party_eggs_path=os.path.join(base, 'eggs_3rd_party'),
        python='python2.6',
        test_requirement=package+'[test]',
    )
# Make the websites
for package in packages:
    pkg_info = buildkit.get_pkg_info(package, os.path.join(base, package))
    buildkit.cp(
        os.path.join(
            base, 
            'eggs', 
            package+'-'+pkg_info['Version'][0]+'.tar.gz'
        ),       
        os.path.join(
            docs_path, 
            'eggs', 
            package+'-'+pkg_info['Version'][0]+'.tar.gz'
        ),
    )
    buildkit.remove_dist(os.path.join(base, package))
    buildkit.build_html_docs(package, os.path.join(base, package))
    buildkit.copy_html_docs(
        docs_path,
        name=package,
        path=os.path.join(base, package),
        version=pkg_info['Version'][0],
    )
    buildkit.package_index_page(
        eggs_path=os.path.join(base, 'eggs'),
        package_docs_path = os.path.join(docs_path, package.lower()),
        template_path = template_path,
        pkg_info=pkg_info,
    )
buildkit.egg_index_page(
    docs_path = docs_path,
    template_path = template_path,
    eggs_path=os.path.join(base, 'eggs'),
)
buildkit.main_index_page(
    docs_path = docs_path,
    template_path = template_path,
    exclude = exclude,
)
