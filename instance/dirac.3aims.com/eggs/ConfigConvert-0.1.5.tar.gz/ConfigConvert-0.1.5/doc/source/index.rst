.. ConfigConvert documentation master file, created by sphinx-quickstart on Thu Feb 26 23:32:18 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

0.1.5
+++++

.. include :: ../index.txt

Documentation
=============

.. toctree::
   :maxdepth: 2

   manual
   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

