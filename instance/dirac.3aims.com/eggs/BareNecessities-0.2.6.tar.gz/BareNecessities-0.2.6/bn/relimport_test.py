from bn import relimport

absimport = relimport(
    '.',
    __file__,
    '.',
    'absimport',
)

