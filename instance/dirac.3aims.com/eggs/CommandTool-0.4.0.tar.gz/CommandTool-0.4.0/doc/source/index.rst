.. CommandTool documentation master file, created by
   sphinx-quickstart on Mon Jun 29 23:26:13 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

0.4.0
+++++

.. include:: ../index.txt

Documentation
=============

The code is based on the blog post at
http://jimmyg.org/blog/2009/python-command-line-interface-(cli)-with-sub-commands.html
but see the documentation below for full, up-to-date information.

.. toctree::
   :maxdepth: 3
 
   manual
   api

.. include:: ../../CHANGELOG.txt

License
=======

.. include:: ../../LICENSE.txt

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

