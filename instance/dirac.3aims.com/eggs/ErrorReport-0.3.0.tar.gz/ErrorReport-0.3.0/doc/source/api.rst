API Documentation
+++++++++++++++++
   
.. automodule:: errorreport 
   :members:
   :undoc-members:
