API Documentation
+++++++++++++++++
   
.. automodule:: appdispatch 
   :members:
   :undoc-members:
