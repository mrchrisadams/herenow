Appendix D: API Documentation
+++++++++++++++++++++++++++++

The :mod:`conversionkit` Module
===============================

.. automodule:: conversionkit
   :members:
   :undoc-members:

