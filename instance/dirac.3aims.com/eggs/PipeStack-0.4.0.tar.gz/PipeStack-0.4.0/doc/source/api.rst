API Documentation
+++++++++++++++++
   
.. automodule:: pipestack 
   :members:
   :undoc-members:
