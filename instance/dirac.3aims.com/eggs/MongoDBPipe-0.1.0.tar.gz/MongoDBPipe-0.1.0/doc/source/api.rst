API Documentation
+++++++++++++++++
   
.. automodule:: mongodbpipe 
   :members:
   :undoc-members:
